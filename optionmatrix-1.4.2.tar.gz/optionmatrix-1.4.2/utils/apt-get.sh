#!/bin/sh

# Copyright (C) 2012 Anthony Bradford.

echo
echo Install proper packages for Debian GNU/Linux distributions
echo

sudo apt-get install g++ clang libncurses5-dev libncurses5 libgtk2.0-dev libgtk-3-dev gsl-bin libgsl0-dev libnewmat10-dev libitpp-dev zip devscripts automake autotools-dev help2man linkchecker aspell diction asciidoc alien texlive texinfo dbtoepub imagemagick
